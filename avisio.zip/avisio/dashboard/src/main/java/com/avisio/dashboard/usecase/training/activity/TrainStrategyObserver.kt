package com.avisio.dashboard.usecase.training.activity

interface TrainStrategyObserver {

    fun resultOptionSelectionProceeded()

}