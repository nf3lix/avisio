package com.avisio.dashboard.usecase.crud_card.common.input_flex_box

interface SelectQuestionImageObserver {

    fun onStartSelect()

}