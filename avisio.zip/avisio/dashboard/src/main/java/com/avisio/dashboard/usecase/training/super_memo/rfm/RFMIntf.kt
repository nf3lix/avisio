package com.avisio.dashboard.usecase.training.super_memo.rfm

interface RFMIntf {

    fun rf(repetition: Int, afIndex: Int): Double

}