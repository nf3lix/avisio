package com.avisio.dashboard.common.data.model.card.question

enum class QuestionTokenType {
    TEXT, IMAGE, QUESTION
}