package com.avisio.dashboard.common.ui.breadcrump

interface BreadCrumbElementClickedListener {

    fun elementClicked(index: Int)

}