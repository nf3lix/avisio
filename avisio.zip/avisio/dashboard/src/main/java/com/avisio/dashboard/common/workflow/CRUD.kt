package com.avisio.dashboard.common.workflow

enum class CRUD {
    CREATE, UPDATE
}