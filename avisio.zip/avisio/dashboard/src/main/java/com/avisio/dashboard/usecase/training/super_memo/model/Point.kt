package com.avisio.dashboard.usecase.training.super_memo.model

data class Point(
    val x: Double,
    val y: Double
)