package com.avisio.dashboard.common.data.model.card.question

data class QuestionToken(
    val content: String,
    val tokenType: QuestionTokenType
)