package com.avisio.dashboard.usecase.crud_box.read.dashboard_item

enum class DashboardItemType {
    FOLDER, BOX
}