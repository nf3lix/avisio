package com.avisio.dashboard.common.ui.breadcrump

class BreadCrumbDirectoryElement(
    val displayName: String?,
    val iconId: Int? = null
)