package com.avisio.dashboard.usecase.crud_box.read.dashboard_item.search_results

data class SearchResultRegionMatch(
    val start: Int,
    val end: Int
)