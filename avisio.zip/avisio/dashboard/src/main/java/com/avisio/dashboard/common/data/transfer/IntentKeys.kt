package com.avisio.dashboard.common.data.transfer

object IntentKeys {

    const val BOX_OBJECT = "BOX_OBJECT_KEY"
    const val CARD_OBJECT = "CARD_OBJECT_KEY"
    const val DASHBOARD_ITEM = "DASHBOARD_ITEM"
    const val EDIT_JOB_FROM_OUTER_SCOPE = "EDIT_JOB_FROM_OUTER_SCOPE"

}